                                           January 18, 2001

Diskeeper[R] 6.0 (Build 380c)
for Windows[R] 95/98/Me, Windows NT[R] 4.0 and Windows 2000


TABLE OF CONTENTS
=================

A.  PRODUCT CERTIFICATION
B.  PLATFORMS AND OPERATING SYSTEM VERSIONS SUPPORTED
C.  OVERVIEW OF DISKEEPER 6
D.  MAJOR FEATURES IN VERSION 6
E.  OTHER KEY DISKEEPER FEATURES
	Frag Guard
	Set It and Forget It[R] Scheduling
	Exclusion List
	Selectable Run Priorities
	Event Logging
F.  CHANGES/CORRECTIONS IN THIS RELEASE
G.  KNOWN RESTRICTIONS IN THIS RELEASE
H.  KNOWN INCOMPATIBILITIES
I.  INSTALLING DISKEEPER 
J.  SETTING ACCESS CONTROL ON WINDOWS 95/98 SYSTEMS
K.  UNINSTALLING DISKEEPER 

-----------------------------------------------------------------


A.  PRODUCT CERTIFICATION
=========================

The Diskeeper 6.0 and Undelete 2.0 Server and Workstation
full versions for Windows are compliant with the Microsoft
Windows 2000 logo certification. 

Unlike the full version of Diskeeper or Undelete, Diskeeper
Trialware and the Deleted File Analysis Utility and the 
additional resources on the Diskeeper CD have not been logo 
tested at this time.
 
The Alpha version of Diskeeper also has not been certified 
for the Windows logo.


B.  PLATFORMS AND OPERATING SYSTEM VERSIONS SUPPORTED
=====================================================

This version of Diskeeper is supported on Intel x86 (or 
compatible) platforms running Windows 95, Windows 98, 
Windows Me, Windows NT 4.0, and Windows 2000.

Note that if this is an update version of Diskeeper and 
you are installing it on a computer that was upgraded to 
Windows 2000 from either Windows NT 4.0 or Windows 9x, 
the update installation will not save any previous settings. 
You will need to re-enter any exclusion lists, "Set It and 
Forget It" schedules and Frag Guard settings.  

Note that Diskeeper requires OSR 2 or higher on Windows 95 
systems.


C.  OVERVIEW OF DISKEEPER 6
===========================

Diskeeper is the leading defragmenter in the Windows enterprise, 
and it continues to improve with each new version.  This version
is no exception -- we have made additional enhancements and 
changes as the result of feedback from customers worldwide.  
Support for Windows Me has been added, further demonstrating 
Diskeeper as "The Standard in Entire Network Defragmentation"[TM].  

Diskeeper 6 introduces Smart Scheduling[TM].  This new option in 
the "Set It and Forget It" scheduling feature can automatically 
determine how often each of your individual disk volumes should 
be defragmented, and create a dynamic schedule to match that need.

In addition to Smart Scheduling, Diskeeper 6 includes a number of 
enhancements to further improve defragmentation performance and
efficiency.

As with version 5.x, Diskeeper relies on both the Distributed 
Component Object Model (DCOM) and the Microsoft Management 
Console (MMC).

DCOM is used for communication between the various components that
make up Diskeeper.  For example, when a Diskeeper defragmentation
operation is scheduled to begin, the Diskeeper controller module
uses DCOM to send a message to the defragmentation engine to begin
the defragmentation process.

The MMC provides a single point of control for system utilities 
such as Diskeeper.  The MMC is used as a central location for a 
variety of Microsoft and third-party administrative tools.

In most cases, Windows 95 systems are not running either DCOM or 
the MMC by default.  On Windows 98 and Windows NT systems, DCOM 
is installed by default when the operating system is installed, 
but the MMC is an additional installation.  The Diskeeper setup 
process automatically installs DCOM and the MMC on your computer 
if it determines either are not already installed.  Windows 2000
has both DCOM and MMC included.  


D.  MAJOR FEATURES IN VERSION 6
===============================

In addition to the core features present in the previous version
of Diskeeper, this version expands on the concept of "Set It and
Forget It" defragmentation.  

Smart Scheduling
----------------

With the addition of Smart Scheduling, you no longer need to
decide how often to defragment your disks -- simply let Diskeeper
automatically determine the optimum defragmentation schedule for
each of your disk volumes.

The method used to determine how often Diskeeper should run is
elegant in its simplicity.  When Smart Scheduling is enabled,
Diskeeper keeps track of the number of files moved every
time it runs on each disk volume.  When the number of files
moved during a defragmentation run increases, Diskeeper
is automatically scheduled to run more often.  When the number 
of files moved decreases, the time between defragmentation runs 
is increased.

The Smart Scheduling option is available in both the Disk Volume
Scheduler and the Network Scheduler features.  It has been added 
to the "Run" drop-down option list.

Note that you can also set exclusion times when the Smart 
Scheduling option will be prevented from scheduling a 
defragmentation run.  When Smart Scheduling is selected, the
"when" drop-down option list will be limited to these times:

	Except Everyday
	Except Weekends
	Except Weekdays
	Except Monday
	Except Tuesday
	Except Wednesday
	Except Thursday
	Except Friday
	Except Saturday
	Except Sunday

You can use the "between" and the "and" drop down lists to 
further define times when the scheduling of automatic 
defragmentation runs will not be allowed.  For example, a
schedule set like this:

	"Run"				"when"
	Smart Scheduling		Except Weekdays


	"between"			"and"
	1:00 am				3:00 am

will allow Diskeeper to automatically determine how often to 
run, but will also prevent it from running between 1:00 am 
and 3:00 am on weekdays (i.e., when your nightly backup is
running).

Defragmentation Improvements
----------------------------

As Diskeeper has matured and grown, so has the engineering
knowledge and expertise that continually goes into improving
its efficiency.  This version includes changes in the way
defragmentation is approached, and the result is better,
faster, and more efficient defragmentation of your disk 
volumes.

If you have used Diskeeper in the past, you will likely see
marked improvement in how thoroughly your disk volumes are
defragmented, and the speed at which the defragmentation is 
done.  These improvements are most noticeable on large 
volumes, but they affect all defragmentation jobs.


E.  OTHER KEY DISKEEPER FEATURES
================================

The following features have been incorporated into previous
versions of Diskeeper.  All of these functions are available 
from the Action menu in the Diskeeper MMC Snap-In:

Frag Guard
----------

Frag Guard is available in the Windows NT and Windows 2000 
versions of Diskeeper only.  Frag Guard and the Diskeeper 
Boot-Time defragmentation function combine to address the 
defragmentation of two critical sections of an NTFS volume, 
the Master File Table (MFT) and the paging file, and keeps 
them that way.

Frag Guard has an online mechanism that minimizes MFT and paging 
file fragmentation, greatly reducing the need for boot-time 
defragmentation runs.  This mechanism also monitors the 
fragmentation levels of the MFT and paging file, and automatically 
sets a boot-time defragmentation operation to run when either of 
these levels exceeds a threshold that you set.  The boot-time 
defragmentation will only occur during a time period you specify.  

The dialog box that controls the Frag Guard settings is displayed 
during setup, but can also be accessed later from the Action menu.

Note that in order for Frag Guard to provide any benefit on most
volumes, it is necessary for you to run a full Boot-Time 
defragmentation of the volume.  This includes defragmenting the 
MFT and paging file, as well as defragmenting and consolidating 
the directories.  This manual Boot-Time defragmentation run 
"clears the way" to allow Frag Guard to function fully.

Set It and Forget It Scheduling
-------------------------------

The "Set It and Forget It" mode allows Diskeeper to run 
automatically in the background while users and other processes 
are active on the system.  To run Diskeeper in the "Set It and 
Forget It" mode, first create a schedule specifying the times 
Diskeeper either will or will not be allowed to run on a 
specific disk volume, then start the scheduled defragmentation 
job.  After a defragmentation schedule is created for a volume, 
Diskeeper will follow that schedule until you explicitly stop it.  
The defragmentation job will run as scheduled, whether you are 
logged onto the computer or not.  Also, multiple "Set It and 
Forget It" defragmentation jobs can be run at the same time on
separate volumes.  

To stop a "Set It and Forget It" defragmentation job, open the Set 
It and Forget It dialog box from the Action menu, highlight the 
disk volume for which you want to stop the schedule, then click 
Stop.  

By default, "Set It and Forget It" defragmentation jobs are run at 
"Lowest" Windows priority.  As an option, you can change the 
priority at which Diskeeper runs for "Set It and Forget It" jobs.  
To do this, select the Priority option from the Action menu.  Note
that raising the priority of Diskeeper jobs can impact the 
performance of other tasks on your system running at the same time, 
but will reduce the amount of time needed to defragment your 
disk volumes.

Exclusion List
--------------

Choose the Exclusion List option from the Action menu to create an
Exclusion List.

In some cases, you may have files or directories of files you do
not want to defragment.  For example, you might not want to 
defragment temporary files that will soon be deleted.  Any files 
or directories can be excluded from Diskeeper processing by 
creating an exclusion list.  

Selectable Run Priorities
-------------------------

Use the Priority option on the Action menu to select the Windows 
priority at which Diskeeper defragmentation jobs run.  You can set 
the priority independently for both "Set It and Forget It" and 
"Manual Defragmentation" defragmentation jobs.  

By default, scheduled, "Set It and Forget It" defragmentation jobs 
run at the lowest Windows priority.  Also by default, 
"Manual Defragmentation" jobs run at the normal Windows priority.  
The priority for either type of defragmentation job can be changed 
with the Priority option.

Running at the lowest priority minimizes the system performance 
impact when Diskeeper is defragmenting a disk volume.  However, 
defragmentation jobs running at the lowest priority can take 
substantially longer to complete than those running at higher 
priorities, since Diskeeper "backs off" for any process running 
at a higher priority (even screen savers).

For this reason, you may have occasions where you want to run 
Diskeeper at a higher priority.  In these instances, use the 
higher priority options.  Keep in mind, though, that your 
system performance may be impacted when Diskeeper is run at 
higher priorities.

Event Logging
-------------

Use the Event Logging option on the Action menu to enable and 
disable the recording of various Diskeeper events to a log file.

On Windows 95/98/Me, the Diskeeper log file is named 
DkEventLog.txt, and it is stored in the directory where 
Diskeeper is installed.  This text file can be viewed with 
Notepad, or your choice of text editor programs.

On Windows NT 4.0 and Windows 2000, the Diskeeper information is 
logged in the Windows Application Event Log.  See the "After 
the Installation" section of the Diskeeper Help for information 
about setting up the Windows NT Application Event Log for optimum
logging operation.


F.  CHANGES/CORRECTIONS IN THIS RELEASE
=======================================

The following list summarizes the changes and corrections that
have been made to Diskeeper from version 5.3.340.7 to version
6.0.377:

1.  The Frag Guard feature is now disabled by default when 
    Diskeeper is installed.  You can enable this feature during 
    installation, or at any time from the Action menu.

2.  A problem that prevented Network Schedules from being correctly 
    broadcast to remote machines has been fixed.

3.  The "Percent Free Space Fragmentation" field in the Diskeeper
    Report View now displays the correct values.

4.  Several cases were reported where the Diskeeper toolbar did not
    display correctly.  Some of these cases have now been fixed.

5.  Under Windows 2000, NTFS directories are now being moved online as
    intended.  As before, directories under Windows 95/98 are
    moved online.  Note that under Windows NT, directories cannot 
    be moved online.

6.  Under certain conditions, a scheduled defragmentation job could
    appear to run continuously.  This has been corrected.

7.  Use has been made of improvements made to the NTFS interface in
    Windows 2000, to make free space consolidation more effective.

8.  The Diskeeper defragmentation algorithms have been further
    improved, especially those addressing partial defragmentation.
    You may find this improvement noticeable even if the volume
    has less than 20% free space.

9.  The NTLDR, NTDETECT.COM, and BOOT.INI files have been added 
    to the Diskeeper internal exclusion list to prevent them from 
    being moved during the defragmentation process.  It has been 
    determined that moving these files beyond the 1024 cylinder 
    boundary on disks with more than 1024 cylinders can, in some 
    cases, prevent a computer from booting properly.

10. In some rare instances, on extremely fragmented NTFS volumes,
    a message indicating a failure to initialize the engine would 
    appear when the engine was started.  This has been corrected.

11. In some cases, under Windows 2000, the reserved MFT zone 
    would "wander", reducing the usefulness of the boot-time 
    MFT defragmenter.  The Diskeeper MFT defragmenter for Windows
    2000 now enforces a a clear space bracketing the MFT zone, so 
    the MFT defragmenter has a chance to work.
 
    Note that under Windows 2000, the MFT zone position is dynamic 
    and cannot be changed by Diskeeper.  It can only be changed by
    the NTFS driver within the file system itself.  

12. In some rare cases, the Windows 2000 boot-time engines would 
    abort prematurely.  This has been corrected.

13. In some cases where an NTFS volume is low on contiguous free 
    space, it appears that the boot-time defragmenter does not 
    fully consolidate the directories.  This is often remedied by 
    simply re-running the NTFS boot-time defragmenter.

14. There have been a limited number of access violations reported
    when running the NTFS defragmentation engine.  Many of these
    situations have been corrected.
 
15. The Windows NT/2000 defragmentation engines were reworked so 
    they run much faster than before on volumes having more than 
    25,000 files.  The speed difference may not be as noticeable 
    on volumes having fewer than 25,000 files.

The following is a list of changes and corrections that have been 
made to Diskeeper from version 6.0.377 to version 6.1.378:

1.  Several changes have been made to the Frag Guard feature to
    improve its effectiveness and reduce the system resource
    usage.

2.  In some cases, if a compressed NTFS file existed on a volume, 
    the rest if the volume would not defragment.  This has been 
    corrected.

The following is a list of changes and corrections that have been 
made to Diskeeper from version 6.0.378 to version 6.1.379:

1.  Improvements have been made in the methods used by Diskeeper
    to defragmented compressed NTFS files.

2.  Changes have been made to more accurately detect and display
    the MFT zone on NTFS volumes.

3.  Changes have been made to improve the manner in which free 
    space is displayed in the Diskeeper graphical interface.

4.  Notation has been added to the Most Fragmented Files list 
    in text report view under Windows 2000 to indicate which 
    files in the list are actually directories, and can therefore
    be defragmented online.

5.  Previous versions of Diskeeper have excluded the 
    ShellIconCache file from being defragmented.  This was 
    intended to address a problem wherein icons would "disappear"
    from the desktop.  It has now been determined that the 
    problem was caused by certain beta versions of Active 
    Desktop.  As a result, changes have been made to allow
    Diskeeper to defragment this file.

The following is a list of changes and corrections that have been 
made to Diskeeper from version 6.0.379 to version 6.0.380:

1.  A correction has been made to the Most Fragmented Files list
    to cause the size of fragmented directories to display 
    properly.

2.  Under Windows 2000, changes have been made to to correct the 
    name of the installation folder shown in the registry.

3.  Several changes have been made to improve "hot key" behavior,
    including the addition of a hot key to close the report view
    dialog box.

4.  Changes have been made to correct problems with tool tips
    displayed in the Italian and German versions of Diskeeper.

5.  Changes in the German version of Diskeeper have been made to
    prevent a system hang during the setup process.

6.  An error message is now displayed when defragmentation of a
    floppy diskette is attempted from the Tools tab in the Disk 
    Properties dialog box.

7.  The proper volume is now highlighted when Diskeeper is 
    started from the Tools tab in the Disk Properties dialog 
    box.

8.  The "Apply selection to all drives" option in the Diskeeper
    Exclusion List now functions correctly.

9.  Corrections have been made to the Set It and Forget It
    dialog box to cause the "between" list box to function
    properly.

10. The Smart Scheduling option has been revised to remove 
    extraneous registry entries.


G.  KNOWN RESTRICTIONS IN THIS RELEASE
======================================

1.  The Windows NT 4.0 version of Diskeeper will not defragment
    NTFS volumes formatted under Windows 2000, or that were 
    upgraded to NTFS 5 volumes. The Windows 2000 version of 
    Diskeeper will defragment these volumes.  If you have a 
    dual-boot system with Windows NT and Windows 2000, it is
    recommended that you defragment all your disk volumes from 
    the Windows 2000 boot.

2.  Under Windows NT, Diskeeper will not defragment FAT32 
    volumes.  It will, however defragment FAT32 volumes when
    running on Windows 98 and Windows 2000 systems.

3.  Boot-Time operations may take a very long time to complete, 
    especially on volumes larger than 9GB with small cluster 
    sizes.  

    IMPORTANT NOTE:  In the event the Boot-Time operation takes
    longer than expected on a mission-critical system, you can 
    safely abort a Diskeeper Boot-Time operation.  To do this, 
    either use the reset switch on the computer or turn the 
    computer's power off, then back on.  The Diskeeper Boot-Time
    operation is designed to prevent any risk to your data, even
    when the computer's power is interrupted.  In the worst 
    case, some blocks of free space may incorrectly be marked as
    allocated when a Boot-Time operation has been interrupted in
    this manner.  To correct this minor issue, Executive Software
    recommends running CHKDSK on a volume after a Boot-Time
    operation has been interrupted the volume.

4.  Boot-Time operations may also take considerable time on
    highly fragmented volumes.  For this reason, Executive
    Software strongly recommends running one or more complete
    defragmentation jobs before running the Boot-Time operation.
 
5.  Connecting to remote computers with the server version of
    Diskeeper can take up to 1 minute, depending on your network
    connection and traffic.

6.  The Diskeeper Server version does not support remote
    connections on a peer-to-peer network.

7.  If User Profiles are enabled on Windows 95/98/Me systems,
    Diskeeper will only be available under the logon of the user
    who installed it.  If you are using multiple user profiles,
    you can install Diskeeper from within each profile to make it
    available to that profile.

8.  Although Diskeeper attempts to lock removable drives, some 
    may not be lockable, or may eject anyway if the eject button 
    is used.  Data corruption may occur if you eject a removable
    disk while defragmentation is occurring on that disk.

9.  When multiple disk volumes are scheduled to be defragmented
    with the same starting time, defragmentation is started on
    the volumes one at a time, with one-minute intervals between
    each starting time.  This is by design.

10. The Boot-Time Defragmentation feature is only available in 
    the Windows NT and Windows 2000 versions of Diskeeper.  Under 
    Windows 95/98/Me, directory consolidation is not necessary, 
    since directories are automatically defragmented by Diskeeper 
    in its online mode.  Swap file defragmentation under Windows 
    95/98/Me is not supported in this version of Diskeeper.

11. If you are running Internet Explorer 4.0 and using Dial Up 
    Networking (DUN) with a modem, starting Diskeeper can cause 
    the DUN dialog box to be displayed.  To work around this, 
    disable connecting through a modem or install Internet 
    Explorer 5.0.  Internet Explorer 5.0 may show similar results
    if the "Always dial my default connection" option is set via 
    the Tools | Internet options | Connection tab set.

12. If you install other software that also loads the MMC, be 
    aware that the other product may install an older version of 
    the MMC.  If this occurs, Diskeeper may not operate correctly,
    and should be reinstalled.

13. FAT volumes larger than 2GB formatted on Windows NT cannot be
    defragmented under Windows 95/98/Me.  This is due to a 2GB FAT 
    volume limit on Windows 95/98/Me systems.

14. The free space figures displayed in the Diskeeper MMC snap-in 
    may not match those shown in the Diskeeper report view if
    you are running Norton Protect.

15. If you are defragmenting a remote computer with the Server 
    version of Diskeeper, shutting down the remote system can
    cause the MMC on the local machine to generate an application
    error.

16. When you use the server version of Diskeeper 6.x to connect 
    to computers running versions of Diskeeper prior to 5.x, the 
    information normally shown in the Diskeeper snap-in (such as 
    capacity and free space figures) is displayed as zeros (0). 
    This is because the earlier versions do not collect this 
    information at the GUI level.

17. When you use the server version of Diskeeper 6.x to connect 
    to computers running versions of Diskeeper prior to 5.x, the 
    progress bar at the bottom of the Diskeeper snap-in display 
    will proceed to 100% several times -- once each time an 
    individual "pass" completes on the pre-V5.0 computer.  

18. When the Notification option has been enabled in the Automatic
    Boot-Time section of the Frag Guard dialog box, the scheduled
    restart will not occur unless you are logged off the computer.

19. When a Diskeeper 6.x server is connected to a workstation
    running Diskeeper 4.1, and the MMC is shut down and re-started
    on the server, the graphic display showing the remote machine
    is blank.

20. When the post-defragmentation summary report is displayed,
    scheduled "Set It and Forget It" defragmentation jobs are
    prevented from starting.  Close the summary report to allow
    the scheduled defragmentation to occur.

21. During periods of high Diskeeper activity (such as starting 
    and stopping analysis and defragmentation on many disk volumes
    in rapid succession), "orphan engines" may be present on your
    computer.  These processes will appear in the Windows NT Task
    Manager under the Processes tab.  In some cases, the orphan
    engines will self-terminate; in other cases you may need to 
    manually end the process via Task Manager.

22. Diskeeper cannot defragment NTFS volumes with a cluster size 
    larger than 4KB in size.  This applies to both online and 
    Boot-Time modes.  Additionally, if the Frag Guard option has 
    been set for an NTFS volume with a cluster size larger than 
    4KB, and the Automatic Restart function determines a Boot-Time 
    defragmentation is necessary, the Boot-Time operation will
    not succeed, and Frag Guard will immediately schedule another
    Boot-Time defragmentation run.  This results in an endless 
    loop condition.  To prevent this situation, do not enable Frag
    Guard on NTFS volumes with a cluster size larger than 4KB.

23. If you are re-installing Diskeeper on a computer running
    Windows 2000, and you allow the installation program to 
    uninstall the previous version, you will not be allowed to 
    select the destination folder for the new installation.
    To be able to specify the destination folder for the new 
    installation, uninstall the previous version of Diskeeper 
    from Control Panel | Add/Remove Programs before installing 
    the new version of Diskeeper.

24. On Windows NT and Windows 95, if you do not have Internet 
    Explorer 3.0 or higher installed, you will not be able to 
    access the Diskeeper Help system interactively from Diskeeper.
    However, you can still run the Diskeeper Help by clicking 
    Start | Programs | Executive Software | Diskeeper Help.

25. In rare cases, the Diskeeper installation will not be able 
    to uninstall a previous version of the Diskeeper service. 
    The error displayed is "Error stopping the Diskeeper 
    Service."  If you receive this error, use Control Panel, 
    Add/Remove Programs to uninstall the previous version of 
    Diskeeper.  This will enable you to resume the installation. 

26. The installation of this version will not automatically 
    uninstall foreign language installations of Diskeeper.  
    This must be done manually.  

27. The Diskeeper Boot-Time operation cannot defragment files 
    with multiple data streams.  Enabling the Services for 
    Macintosh feature in Windows NT/2000 is one cause of 
    multiple data stream files.  Also note that once a file
    has acquired multiple data streams, copying or moving the
    file to another volume will not remove the multiple data
    stream characteristics.  Thus, even if you have never used
    the Services for Macintosh feature, there is still a 
    possibility that you have acquired files with these
    characteristics (i.e., through software installations).


H.  KNOWN INCOMPATIBILITIES
===========================

1.  Diskeeper will not run on disk volumes that are locked by 
    utilities such as Scandisk.

2.  We have noted occasional problems in defragmenting volumes 
    that have been configured or resized with Partition Magic.  
    If you are having problems defragmenting a volume, and it 
    has previously been configured or resized with Partition 
    Magic, it may be necessary to backup, reformat, and restore 
    the volume prior to running Diskeeper.

3.  When using an IOMEGA JAZ drive with the IOMEGA Quick.exe 
    application installed, you may receive the following blue 
    screen error message when you log on to the computer using 
    an administrative account: 

       Stop 0x0000000A (parameter,parameter,parameter,parameter)
       IRQL_NOT_LESS_OR_EQUAL. 

    The IOMEGA Quick.exe application is installed in the Startup 
    group to start automatically.  It sends invalid system calls 
    that are only allowed when logged on as an administrator. 
    When the Diskeeper Boot-Time operation is run, the Quick.exe 
    application is delayed in starting, thus causing the above 
    problem.

4.  The Hercules Terminator AGP 128/3D "GLH" 8MB also does not 
    appear to display the full Boot-Time dialog, and thus appears 
    to hang when the "Pause at End" option in the Diskeeper 
    Boot-Time option has been selected.


I.  INSTALLING DISKEEPER 
========================

Windows NT Note: If you have previously installed Diskeeper Lite 
on your computer, Executive Software recommends that you uninstall 
it before proceeding with the installation of Diskeeper.  If, 
however, you decide to leave Diskeeper Lite on your system, be 
aware that uninstalling Diskeeper Lite after the installation will 
remove certain Windows NT registry entries used by Diskeeper, 
and you will need to re-install Diskeeper.  Use the Add/Remove 
Programs applet in Control Panel to uninstall Diskeeper Lite.

Note: On Windows NT machines, you must have Service Pack 3 or 
higher installed.  Also, you must be logged into an account 
that is a member of the Administrators group.

Note: If you are installing an update version of Diskeeper 6.0,
you must have Diskeeper installed on your system, or have either 
the Diskeeper 5.x CD-ROM or the downloaded self-extracting 
compressed file for Diskeeper 5.x present on your system.

Diskeeper is available either as a downloaded self-extracting 
compressed file, or on CD-ROM.  The following instructions
apply to both formats.

Follow these steps to install Diskeeper:

1.  If your Diskeeper package is a self-extracting compressed file,
    download the package into a temporary directory.  If your 
    Diskeeper package is contained on a CD-ROM, insert it into the 
    appropriate drive on your computer.

2a. (Download version only) From Windows Explorer, double click 
    file you downloaded in the temporary directory.  Once started, 
    Setup will ask you where you want the installation files to be 
    unpacked.  Either select the default or specify the desired 
    folder. 

2b. (CD-ROM Version Only) The Windows AutoPlay feature 
    automatically determines the computer platform you are using 
    and begins installing the correct version of Diskeeper.  If 
    you have disabled the AutoPlay feature, double-click SETUP.EXE 
    in the directory folder representing your computer platform.  
    If SETUP.EXE does not exist on your version of the CD-ROM,
    double click the *.msi file instead.  This causes the Diskeeper 
    Setup window to be displayed.

3.  If Internet Explorer 4.01 or higher is not installed on your 
    computer, the Diskeeper Setup program is stopped.  Another
    installation program is started and a package of necessary 
    components is installed on your computer.  Microsoft 
    Management Console (MMC), which is the interface for 
    Diskeeper, requires these components.  These components 
    are a small subset of Internet Explorer -- not the complete
    Internet Explorer product.  Installing these components will
    not affect your current web browser.  Note that you must
    restart your computer after installing the component pack
    before you can continue installing Diskeeper.

4.  If the MMC is not installed on your computer, the Diskeeper 
    Setup program is paused and the MMC Setup program is started 
    automatically.  After the MMC files are installed, the 
    Diskeeper Setup program resumes.

5.  On Windows 95/98/NT systems, the Setup program checks to 
    confirm DCOM is installed on your computer.  If it is not, the
    Diskeeper Setup program exits and the DCOM Setup program is 
    begun.  After a short period of copying files, the DCOM 
    installation is complete.

6.  Click Next when the welcome message appears.

7.  The installation procedure detects and removes any previously 
    installed Diskeeper software. 

    Note that if you are installing an update version of
    Diskeeper on a computer that was upgraded to Windows 2000 from
    either Windows NT or Windows 98, this update installation
    will not save any previous settings.  You will need to re-enter 
    any exclusion lists, "Set It and Forget It" schedules and 
    Frag Guard settings. 

8.  As an option, you can change the destination location for the 
    Diskeeper files.  By default, Diskeeper is installed in one of 
    the following locations on your Windows system volume, 
    depending on the version installed:

    \Program Files\Executive Software\Diskeeper\DiskeeperSvr
    \Program Files\Executive Software\Diskeeper\DiskeeperWks
    \Program Files\Executive Software\Diskeeper\Diskeeper9x

    To choose another disk volume or directory on Windows
    95/98/Me, click Browse.  If you choose another volume or 
    directory, click OK to accept the new destination location.  
    Any valid local disk volume and directory name is acceptable.  
    If the directory you specify does not exist, a new directory 
    will be created by the Setup utility.

    Under Windows NT/2000, you can choose a different disk volume 
    or directory for the installation by following these steps:

    a) Select the Custom option button and click Next.

    b) You can check if there is sufficient disk space for 
       Diskeeper on any of your local volumes by clicking on 
       Disk Usage.

    c) Click Change, make the desired changes to the destination 
       and click Next to accept the new destination.  If the 
       directory you specify does not exist, a new directory 
       will be created.
    
9.  After the Diskeeper files have been copied to your system, 
    you are presented with the opportunity to register Diskeeper 
    online.  You can also register Diskeeper at a later time via 
    the Executive Software Web site at www.diskeeper.com.

10. On a Windows 2000 system, after Setup is complete, you may 
    immediately start Diskeeper after clicking Finish. 
    On other operating systems, you must first restart your 
    computer before running Diskeeper.

11. To run Diskeeper, click the Windows Start button and select 
    Programs, Executive Software, and then Diskeeper.


J.  SETTING ACCESS CONTROL ON WINDOWS 95/98 SYSTEMS
===================================================

In some cases, the Diskeeper setup program will inform you
that it is necessary for you to change the access control 
settings on Windows 95/98 systems.  If such a message is 
displayed during the installation, follow these steps to
set the access control:

1.  From the Windows Control Panel, double-click "Network".

2.  Click the Access Control tab.

3.  Enable "User-level access control".

4.  Specify the correct domain, if necessary.


K.  UNINSTALLING DISKEEPER
==========================

Follow these steps to remove Diskeeper from your computer:

1.  From Control Panel, double click "Add/Remove Programs".

2.  Click the "Install/Uninstall" tab.

3.  Highlight "Diskeeper".

4.  Click "Add/Remove".  This removes the Diskeeper program 
    files from your computer.

5.  When prompted, click "Yes" to remove the Roboex32.dll
    shared file, unless you know of other programs on your
    computer that also use this file.  If this is the case,
    click "No" instead.

6.  It may be necessary to manually delete the Diskeeper 
    installation directory after the uninstall process
    is complete.

Note: If the MMC and DCOM have been installed on your 
computer, they will not be removed when Diskeeper is 
uninstalled.




(c) Copyright 2001 Executive Software International, Inc.  
    All rights reserved.

Diskeeper, Executive Software, Frag Guard and "Set It and
Forget It" are registered trademarks owned by Executive 
Software International, Inc.

"The Standard in Entire Network Defragmentation"  and
"Smart Scheduling" are trademarks owned by Executive Software 
International, Inc.

Microsoft, Windows, and Windows NT are registered 
trademarks owned by Microsoft Corporation.

All other trademarks are the property of their respective owners.
